<?php
// php_app/api/api_keys.php
require_once __DIR__ . '/../shared/config.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['userId'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$db = read_db();

if ($method === 'GET') {
    $keys = array_values(array_filter($db['apiKeys'], function($k) {
        return $k['userId'] === $_SESSION['userId'];
    }));
    
    // Add database names
    foreach ($keys as &$key) {
        foreach ($db['databases'] as $d) {
            if ($d['id'] === $key['databaseId']) {
                $key['databaseName'] = $d['name'];
                break;
            }
        }
    }
    
    echo json_encode($keys);

} elseif ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $databaseId = $data['databaseId'] ?? '';
    $name = $data['name'] ?? 'Default';

    if (empty($databaseId)) {
        http_response_code(400);
        echo json_encode(['error' => 'Database ID required']);
        exit;
    }

    $newKey = [
        'id' => generate_uuid(),
        'databaseId' => $databaseId,
        'userId' => $_SESSION['userId'],
        'keyValue' => bin2hex(random_bytes(16)),
        'name' => $name,
        'isActive' => true,
        'createdAt' => date('c'),
        'lastUsedAt' => null
    ];

    $db['apiKeys'][] = $newKey;
    write_db($db);
    echo json_encode($newKey);
}
?>