<?php
// php_app/api/auth.php
require_once __DIR__ . '/../shared/config.php';
session_start();

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$data = json_decode(file_get_contents('php://input'), true);

if ($action === 'register') {
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';
    $displayName = $data['displayName'] ?? $email;

    if (!$email || !$password) {
        http_response_code(400);
        echo json_encode(['error' => 'Email and password required']);
        exit;
    }

    $db = read_db();
    foreach ($db['users'] as $user) {
        if ($user['email'] === $email) {
            http_response_code(409);
            echo json_encode(['error' => 'An account with this email already exists.']);
            exit;
        }
    }

    $newUser = [
        'id' => generate_uuid(),
        'email' => $email,
        'password' => password_hash($password, PASSWORD_BCRYPT),
        'displayName' => $displayName,
        'createdAt' => date('c')
    ];

    $db['users'][] = $newUser;
    $db['userRoles'][] = ['id' => generate_uuid(), 'userId' => $newUser['id'], 'role' => 'user'];
    write_db($db);

    $_SESSION['userId'] = $newUser['id'];
    echo json_encode(['user' => ['id' => $newUser['id'], 'email' => $newUser['email'], 'displayName' => $newUser['displayName']]]);

} elseif ($action === 'login') {
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';

    $db = read_db();
    $foundUser = null;
    foreach ($db['users'] as $user) {
        if ($user['email'] === $email) {
            $foundUser = $user;
            break;
        }
    }

    if (!$foundUser || !password_verify($password, $foundUser['password'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid email or password.']);
        exit;
    }

    $_SESSION['userId'] = $foundUser['id'];
    echo json_encode(['user' => ['id' => $foundUser['id'], 'email' => $foundUser['email'], 'displayName' => $foundUser['displayName']]]);

} elseif ($action === 'logout') {
    session_destroy();
    echo json_encode(['success' => true]);

} elseif ($action === 'me') {
    if (!isset($_SESSION['userId'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Not authenticated']);
        exit;
    }

    $db = read_db();
    foreach ($db['users'] as $user) {
        if ($user['id'] === $_SESSION['userId']) {
            echo json_encode(['user' => ['id' => $user['id'], 'email' => $user['email'], 'displayName' => $user['displayName']]]);
            exit;
        }
    }
    http_response_code(401);
    echo json_encode(['error' => 'Not authenticated']);
}
?>