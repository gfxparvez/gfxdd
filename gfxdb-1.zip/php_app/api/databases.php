<?php
// php_app/api/databases.php
require_once __DIR__ . '/../shared/config.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['userId'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$db = read_db();

if ($method === 'GET') {
    $userDatabases = array_values(array_filter($db['databases'], function($d) {
        return $d['userId'] === $_SESSION['userId'];
    }));
    echo json_encode($userDatabases);

} elseif ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $name = $data['name'] ?? '';
    $description = $data['description'] ?? '';

    if (empty(trim($name))) {
        http_response_code(400);
        echo json_encode(['error' => 'Name required']);
        exit;
    }

    $newDb = [
        'id' => generate_uuid(),
        'userId' => $_SESSION['userId'],
        'name' => trim($name),
        'description' => $description,
        'status' => 'active',
        'createdAt' => date('c'),
        'updatedAt' => date('c')
    ];

    $db['databases'][] = $newDb;
    
    // Create default API key
    $db['apiKeys'][] = [
        'id' => generate_uuid(),
        'databaseId' => $newDb['id'],
        'userId' => $_SESSION['userId'],
        'keyValue' => bin2hex(random_bytes(16)),
        'name' => 'Default',
        'isActive' => true,
        'createdAt' => date('c'),
        'lastUsedAt' => null
    ];

    write_db($db);
    echo json_encode($newDb);
}
?>