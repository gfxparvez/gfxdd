<?php
// php_app/api/rows.php
require_once __DIR__ . '/../shared/config.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['userId'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$db = read_db();
$table_id = $_GET['table_id'] ?? null;

if ($method === 'GET' && $table_id) {
    $rows = array_values(array_filter($db['tableRows'], function($r) use ($table_id) {
        return $r['tableId'] === $table_id;
    }));
    echo json_encode($rows);

} elseif ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $tableId = $data['tableId'] ?? '';
    $rowData = $data['data'] ?? [];

    if (empty($tableId)) {
        http_response_code(400);
        echo json_encode(['error' => 'Table ID required']);
        exit;
    }

    $newRow = [
        'id' => generate_uuid(),
        'tableId' => $tableId,
        'data' => $rowData,
        'createdAt' => date('c'),
        'updatedAt' => date('c')
    ];

    $db['tableRows'][] = $newRow;
    write_db($db);
    echo json_encode($newRow);
}
?>