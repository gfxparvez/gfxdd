<?php
// php_app/api/stats.php
require_once __DIR__ . '/../shared/config.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['userId'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}

$db = read_db();
$userId = $_SESSION['userId'];

$stats = [
    'databases' => 0,
    'apiKeys' => 0,
    'requests' => 0
];

foreach ($db['databases'] as $d) {
    if ($d['userId'] === $userId) $stats['databases']++;
}

foreach ($db['apiKeys'] as $k) {
    if ($k['userId'] === $userId) $stats['apiKeys']++;
}

foreach ($db['queryLogs'] as $l) {
    if ($l['userId'] === $userId) $stats['requests']++;
}

echo json_encode($stats);
?>