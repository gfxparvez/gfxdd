<?php
// php_app/api/tables.php
require_once __DIR__ . '/../shared/config.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['userId'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$db = read_db();
$database_id = $_GET['database_id'] ?? null;

if ($method === 'GET' && $database_id) {
    $tables = array_values(array_filter($db['databaseTables'], function($t) use ($database_id) {
        return $t['databaseId'] === $database_id;
    }));
    echo json_encode($tables);

} elseif ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $name = $data['name'] ?? '';
    $databaseId = $data['databaseId'] ?? '';

    if (empty(trim($name)) || empty($databaseId)) {
        http_response_code(400);
        echo json_encode(['error' => 'Name and Database ID required']);
        exit;
    }

    $newTable = [
        'id' => generate_uuid(),
        'databaseId' => $databaseId,
        'name' => trim($name),
        'createdAt' => date('c'),
        'updatedAt' => date('c')
    ];

    $db['databaseTables'][] = $newTable;
    write_db($db);
    echo json_encode($newTable);
}
?>