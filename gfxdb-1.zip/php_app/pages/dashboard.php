<?php
// php_app/pages/dashboard.php
require_once __DIR__ . '/../shared/config.php';
session_start();

if (!isset($_SESSION['userId'])) {
    header('Location: login.php');
    exit;
}

$db = read_db();
$userDatabases = array_filter($db['databases'], function($d) {
    return $d['userId'] === $_SESSION['userId'];
});
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx_auto p-8">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold">My Databases</h1>
            <button onclick="logout()" class="text-red-500">Logout</button>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <?php foreach ($userDatabases as $database): ?>
                <div class="bg-white p-4 rounded shadow">
                    <h2 class="font-bold text-lg"><?php echo htmlspecialchars($database['name']); ?></h2>
                    <p class="text-gray-600"><?php echo htmlspecialchars($database['description']); ?></p>
                    <div class="mt-4">
                        <span class="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">
                            <?php echo htmlspecialchars($database['status']); ?>
                        </span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <script>
        async function logout() {
            await fetch('../api/auth.php?action=logout');
            window.location.href = 'index.php';
        }
    </script>
</body>
</html>