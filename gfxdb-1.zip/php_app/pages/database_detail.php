<?php
// php_app/pages/database_detail.php
require_once __DIR__ . '/../shared/config.php';
session_start();

if (!isset($_SESSION['userId'])) {
    header('Location: login.php');
    exit;
}

$db_id = $_GET['id'] ?? '';
$db_data = read_db();
$current_db = null;

foreach ($db_data['databases'] as $d) {
    if ($d['id'] === $db_id && $d['userId'] === $_SESSION['userId']) {
        $current_db = $d;
        break;
    }
}

if (!$current_db) {
    die("Database not found or access denied.");
}

$tables = array_filter($db_data['databaseTables'], function($t) use ($db_id) {
    return $t['databaseId'] === $db_id;
});
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Database: <?php echo htmlspecialchars($current_db['name']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx_auto p-8">
        <a href="dashboard.php" class="text-blue-500 mb-4 inline-block">&larr; Back to Dashboard</a>
        <h1 class="text-3xl font-bold mb-2"><?php echo htmlspecialchars($current_db['name']); ?></h1>
        <p class="text-gray-600 mb-8"><?php echo htmlspecialchars($current_db['description']); ?></p>

        <h2 class="text-xl font-bold mb-4">Tables</h2>
        <div class="space-y-4">
            <?php foreach ($tables as $table): ?>
                <div class="bg-white p-4 rounded shadow flex justify-between items-center">
                    <span class="font-medium"><?php echo htmlspecialchars($table['name']); ?></span>
                    <a href="table_data.php?id=<?php echo $table['id']; ?>" class="text-blue-500">View Data</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>