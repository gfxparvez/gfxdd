<?php
// php_app/pages/landing.php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PHP Database Platform</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-900 text-white min-h-screen flex flex-col justify-center items-center">
    <div class="text-center max-w-2xl px-4">
        <h1 class="text-5xl font-extrabold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-indigo-500">
            The Modern Database Platform
        </h1>
        <p class="text-xl text-slate-400 mb-8">
            Manage your data with ease using our PHP-powered backend. Fast, secure, and reliable.
        </p>
        <div class="space-x-4">
            <?php if (isset($_SESSION['userId'])): ?>
                <a href="dashboard.php" class="bg-blue-600 px-8 py-3 rounded-lg font-bold hover:bg-blue-700 transition">Go to Dashboard</a>
            <?php else: ?>
                <a href="register.php" class="bg-blue-600 px-8 py-3 rounded-lg font-bold hover:bg-blue-700 transition">Get Started</a>
                <a href="login.php" class="bg-slate-800 px-8 py-3 rounded-lg font-bold hover:bg-slate-700 border border-slate-700 transition">Login</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>