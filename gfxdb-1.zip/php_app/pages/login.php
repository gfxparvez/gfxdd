<?php
// php_app/pages/login.php
session_start();
if (isset($_SESSION['userId'])) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="bg-white p-8 rounded shadow-md w-96">
        <h1 class="text-2xl font-bold mb-6 text-center">Login</h1>
        <div id="error" class="hidden bg-red-100 text-red-700 p-2 mb-4 rounded text-sm"></div>
        <form onsubmit="handleLogin(event)" class="space-y-4">
            <div>
                <label class="block text-sm font-medium">Email</label>
                <input type="email" id="email" required class="w-full border p-2 rounded">
            </div>
            <div>
                <label class="block text-sm font-medium">Password</label>
                <input type="password" id="password" required class="w-full border p-2 rounded">
            </div>
            <button type="submit" class="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">Login</button>
        </form>
        <p class="mt-4 text-center text-sm">Don't have an account? <a href="register.php" class="text-blue-600">Register</a></p>
    </div>
    <script>
        async function handleLogin(e) {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const errorDiv = document.getElementById('error');
            
            const res = await fetch('../api/auth.php?action=login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            
            const data = await res.json();
            if (res.ok) {
                window.location.href = 'dashboard.php';
            } else {
                errorDiv.textContent = data.error || 'Login failed';
                errorDiv.classList.remove('hidden');
            }
        }
    </script>
</body>
</html>