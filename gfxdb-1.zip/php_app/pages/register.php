<?php
// php_app/pages/register.php
session_start();
if (isset($_SESSION['userId'])) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="bg-white p-8 rounded shadow-md w-96">
        <h1 class="text-2xl font-bold mb-6 text-center">Register</h1>
        <div id="error" class="hidden bg-red-100 text-red-700 p-2 mb-4 rounded text-sm"></div>
        <form onsubmit="handleRegister(event)" class="space-y-4">
            <div>
                <label class="block text-sm font-medium">Display Name</label>
                <input type="text" id="displayName" class="w-full border p-2 rounded">
            </div>
            <div>
                <label class="block text-sm font-medium">Email</label>
                <input type="email" id="email" required class="w-full border p-2 rounded">
            </div>
            <div>
                <label class="block text-sm font-medium">Password</label>
                <input type="password" id="password" required class="w-full border p-2 rounded">
            </div>
            <button type="submit" class="w-full bg-green-600 text-white p-2 rounded hover:bg-green-700">Register</button>
        </form>
        <p class="mt-4 text-center text-sm">Already have an account? <a href="login.php" class="text-blue-600">Login</a></p>
    </div>
    <script>
        async function handleRegister(e) {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const displayName = document.getElementById('displayName').value;
            const errorDiv = document.getElementById('error');
            
            const res = await fetch('../api/auth.php?action=register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password, displayName })
            });
            
            const data = await res.json();
            if (res.ok) {
                window.location.href = 'dashboard.php';
            } else {
                errorDiv.textContent = data.error || 'Registration failed';
                errorDiv.classList.remove('hidden');
            }
        }
    </script>
</body>
</html>