<?php
// php_app/pages/table_data.php
require_once __DIR__ . '/../shared/config.php';
session_start();

if (!isset($_SESSION['userId'])) {
    header('Location: login.php');
    exit;
}

$table_id = $_GET['id'] ?? '';
$db_data = read_db();
$current_table = null;

foreach ($db_data['databaseTables'] as $t) {
    if ($t['id'] === $table_id) {
        $current_table = $t;
        break;
    }
}

if (!$current_table) {
    die("Table not found.");
}

$rows = array_filter($db_data['tableRows'], function($r) use ($table_id) {
    return $r['tableId'] === $table_id;
});
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Table: <?php echo htmlspecialchars($current_table['name']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx_auto p-8">
        <a href="database_detail.php?id=<?php echo $current_table['databaseId']; ?>" class="text-blue-500 mb-4 inline-block">&larr; Back to Database</a>
        <h1 class="text-3xl font-bold mb-8">Table: <?php echo htmlspecialchars($current_table['name']); ?></h1>

        <div class="bg-white rounded shadow overflow-x_auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50 border-b">
                        <th class="p-4 font-bold">ID</th>
                        <th class="p-4 font-bold">Data</th>
                        <th class="p-4 font-bold">Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rows as $row): ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="p-4 text-sm font-mono"><?php echo htmlspecialchars($row['id']); ?></td>
                            <td class="p-4">
                                <pre class="text-xs bg-gray-100 p-2 rounded"><?php echo htmlspecialchars(json_encode($row['data'], JSON_PRETTY_PRINT)); ?></pre>
                            </td>
                            <td class="p-4 text-sm text-gray-500"><?php echo htmlspecialchars($row['createdAt']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>