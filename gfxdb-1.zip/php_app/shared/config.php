<?php
// php_app/shared/config.php
define('DB_PATH', __DIR__ . '/../../maindb.json');

function read_db() {
    if (!file_exists(DB_PATH)) {
        return [
            'users' => [],
            'userRoles' => [],
            'databases' => [],
            'databaseTables' => [],
            'tableColumns' => [],
            'tableRows' => [],
            'apiKeys' => [],
            'queryLogs' => []
        ];
    }
    return json_decode(file_get_contents(DB_PATH), true);
}

function write_db($data) {
    file_put_contents(DB_PATH, json_encode($data, JSON_PRETTY_PRINT));
}

function generate_uuid() {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}
?>